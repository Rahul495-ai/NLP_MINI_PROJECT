# nlp_mini_project.py
# NLP Mini Project using TextBlob

from textblob import TextBlob

def main():
    print("=== NLP Mini Project ===")
    text = input("Enter text: ")
    blob = TextBlob(text)

    # Translation Example (English -> Hindi)
    try:
        translated = blob.translate(to="hi")
        print("\n🔹 Translation (EN → HI):", translated)
    except Exception as e:
        print("\n⚠️ Translation skipped (requires internet connection)")

    # Sentiment Analysis
    sentiment = blob.sentiment
    print("\n🔹 Sentiment Analysis:")
    print("Polarity:", sentiment.polarity)  # -1 (negative) to +1 (positive)
    print("Subjectivity:", sentiment.subjectivity)  # 0 (objective) to 1 (subjective)

    # POS Tagging
    print("\n🔹 POS Tagging:")
    print(blob.tags)

    # Spell Checking
    print("\n🔹 Spell Check:")
    corrected = blob.correct()
    print("Corrected Text:", corrected)

    # Noun Phrase Extraction
    print("\n🔹 Noun Phrases:")
    print(blob.noun_phrases)

    # Simple Summarization (pick first 2 sentences as "summary")
    print("\n🔹 Text Summarization (Simple):")
    sentences = blob.sentences
    summary = " ".join(str(s) for s in sentences[:2])
    print("Summary:", summary)

if __name__ == "__main__":
    main()
