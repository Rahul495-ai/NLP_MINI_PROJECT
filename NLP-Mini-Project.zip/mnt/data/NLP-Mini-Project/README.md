# NLP Mini Project (TextBlob)

This project demonstrates basic NLP tasks using **TextBlob**:
- Translation (EN → HI)
- Sentiment Analysis
- POS Tagging
- Spell Checking
- Noun Phrase Extraction
- Simple Summarization

## Quick Start (Local)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate
pip install -r requirements.txt

python -m textblob.download_corpora  # downloads required NLTK data
python nlp_mini_project.py
```

## Quick Start (Google Colab)
```python
!pip install textblob nltk
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('averaged_perceptron_tagger')
nltk.download('brown')
nltk.download('wordnet')
nltk.download('movie_reviews')
# optional: !python -m textblob.download_corpora
```

Then run the code cell with the content of `nlp_mini_project.py`.

> Note: Translation may be skipped if the translate endpoint is blocked or there's no internet.

## Example Input
```
I love playing cricket. It is very exciting but sometimes exhausting.
```

## Example Output (abridged)
```
🔹 Sentiment Analysis:
Polarity: 0.35
Subjectivity: 0.6

🔹 POS Tagging:
[('I','PRP'), ('love','VBP'), ('playing','VBG'), ...]

🔹 Spell Check:
Corrected Text: I love playing cricket. It is very exciting but sometimes exhausting.

🔹 Noun Phrases:
['playing cricket']

🔹 Text Summarization (Simple):
Summary: I love playing cricket. It is very exciting but sometimes exhausting.
```

## Project Structure
```
NLP-Mini-Project/
├─ nlp_mini_project.py
├─ requirements.txt
└─ README.md
```
